# Stylized Student HTML Snippet Package

This archive contains the extracted and stylized HTML snippets from the supplied Word document.

## Structure

- `01-student-sign-up.html`
- `02-verify-otp.html`
- `03-create-new-password.html`
- `04-student-login.html`
- `05-forgot-password.html`
- `06-student-profile.html`
- `07-skills.html`
- `08-projects.html`
- `09-latex-cv-builder.html`
- `10-academic-records.html`
- `assets/css/design-system.css` shared design tokens, components, dark mode, skeleton states, and responsive rules
- `assets/js/app.js` shared modal, theme, pagination, loading, and utility behavior
- `assets/js/pages/` page-specific behavior fixes and pagination/search controllers

Open `index.html` first for the file launcher.
