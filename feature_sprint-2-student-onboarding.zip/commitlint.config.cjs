module.exports = {
  rules: {},
}
